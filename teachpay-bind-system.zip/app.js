// TeachPay 綁卡系統示範主程式
const express = require('express');
const app = express();

app.use(express.json());

app.post('/bind', (req, res) => {
    const { phone, mpin, gcashRegisterDate } = req.body;
    // 模擬綁定邏輯
    if (!phone || !mpin) {
        return res.status(400).json({ error: '缺少必要資料' });
    }
    // 這裡實際應該連接資料庫與掃臉API
    res.json({ status: '綁定成功', phone });
});

app.listen(3000, () => {
    console.log('TeachPay 綁卡系統運行中，端口3000');
});