# TeachPay 綁卡系統
這是TeachPay綁卡系統的主要程式碼。

功能：
- 綁定GCash帳戶
- 掃臉驗證
- MPIN變更

請依需求擴充。